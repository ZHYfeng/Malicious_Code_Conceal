#ifndef PNSCAN_BM_H
#define PNSCAN_BM_H

extern int
bm_setup(void *ss, int sslen);

extern int
bm_search(void *buffer, int n);

#endif
