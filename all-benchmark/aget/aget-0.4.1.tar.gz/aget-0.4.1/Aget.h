#ifndef AGET_H
#define AGET_H

#include "Data.h"
#include "Resume.h"

void get(struct request *);
void resume_get(struct hist_data *);

#endif
