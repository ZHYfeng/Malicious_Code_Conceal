#ifndef HEAD_H
#define HEAD_H

#include "Data.h"

void http_head_req(struct request *);

#endif
