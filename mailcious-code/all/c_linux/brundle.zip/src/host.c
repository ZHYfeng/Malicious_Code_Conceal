/*
 * Brundle Fly - Good-natured Linux ELF virus supporting kernel 2.2 and 2.4
 * Copyright 2001 Konrad Rieck <kr@roqe.org>, Konrad Kretschmer <kk@roqe.org>
 * In memory to Seth Brundle 
 *
 * Nothing to say. This is a host! That's all ...
 *
 * $Id: host.c,v 1.6 2001/07/11 18:34:48 kr Exp $
 */

#include <stdio.h>

int main(int argc, char **argv)
{
    printf("I am a typical host, unfortunatly...\n");
    printf("You see, I'm okay, don't you?\n");
    return 1;
}
