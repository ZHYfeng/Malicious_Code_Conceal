Win32.Cairuh.A [Wrm] Created by Bull Moose GPL License

Based on Conficker, MyDoom, Newstar v4(Mine), and NetSky.AE.

Encrypts most strings using the CiphStr() function in lib.c, Persistant Infection**, PE32 Infection,
Network Exploit Spread (Optimized), Backdoor that accepts files/saves to system32 as random filename and
executes it, Anti Virus Terminator, P2P Spread, USB Spread, Anti Debugging VIA IsDebuggerPresent(), and 
Blocks Websites using the HOSTS file. Upon Compilation from the makefile, it packs then modifies the UPX 
Section names to prevent decompressing.

** = Modifies run, exefile, and comfile keys in registry.
When supplied an argument for exefile and comfile, the file shall be overwritten.

My next release shall most likely be one of these:
- Metamorphic C Virus
- Mass Mailer Worm