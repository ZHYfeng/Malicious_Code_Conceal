compile soft in /work first;

msvcrt6.lib - "msvcrt.lib" from MSVC 5/6.
DO NOT USE "msvcrt.lib" from MSVC .Net!!!
