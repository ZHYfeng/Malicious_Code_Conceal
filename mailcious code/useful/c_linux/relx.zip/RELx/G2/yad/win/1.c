#include <windows.h>
#include <winnt.h>

main()
{
	printf("%x\n", sizeof(IMAGE_FILE_HEADER));
}
