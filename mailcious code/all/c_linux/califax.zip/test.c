#include <stdio.h>

int main(void)
{
   int i;
   for (i = 0; i < 10; i++)
      	close(-11);
      
   return 0;
}
   	
