/* main() for califax.c
 * (C)opyright 1998 by Stealthf0rk / SVAT <stealth@cyberspace.org>
 * use it under the terms of the GPL.
 */
 
int main(void)
{
   	printf("started califax. For Doreen.\n");
        return close(-11);
}

