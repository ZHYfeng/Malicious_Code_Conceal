## System info
**Operating System**: <e.g. macOS Sierra, Ubuntu 14.04 trusty etc>
**Shaka Packager Version**: <e.g. v1.6.1, commit SHA etc>

## Issue and steps to reproduce the problem

**Packager Command**:

Extra steps to reproduce the problem?
(1)
(2)

What is the expected result?

What happens instead?

<Please attach the input files or email to shaka-packager-issues@google.com.>
<Please provide any additional information below.>
