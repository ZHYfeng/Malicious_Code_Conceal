General encryption options
^^^^^^^^^^^^^^^^^^^^^^^^^^

--protection_scheme <scheme>

    Specify a protection scheme, 'cenc' or 'cbc1' or pattern-based protection
    schemes 'cens' or 'cbcs'.

--vp9_subsample_encryption, --novp9_subsample_encryption

    Enable / disable VP9 subsample encryption. Enabled by default.

--clear_lead <seconds>

    Clear lead in seconds if encryption is enabled.
