copy ../../../x64/Release/MultiversoCLR.dll .
nuget pack MultiversoCLR.nuspec