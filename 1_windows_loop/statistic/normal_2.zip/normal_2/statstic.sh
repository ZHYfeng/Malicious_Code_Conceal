#!/bin/bash
for FILE in ./loop* 
do 
    python3 ../../../0_statstic/script/calc_subsec_and_sort_temp.py -f $FILE -s 1-2-3-4 
done

